#ifndef ADMIN_CREDENTIALS
#define ADMIN_CREDENTIALS

#define ADMIN_LOGIN_ID "Admin"
#define ADMIN_PASSWORD "66DLo.AtVrrm." //1234

#endif